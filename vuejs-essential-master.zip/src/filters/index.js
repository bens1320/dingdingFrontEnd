import Vue from 'vue'
import moment from './moment'

Vue.filter('moment', moment)