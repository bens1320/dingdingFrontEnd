<template>
    <div>
        <Message :show.sync="msgShow" :type="msgType" :msg="msg"/>
        <!-- 帖子列表 -->
        <div class="col-md-12 topics-index main-col" >
            <div class="panel panel-default">
                <div class="">
                    <div class="panel-heading text-left">
                        <div class="col-md-6 col-md-offset-3">
                            <div class="panel-body" data-validator-form>
                                <div class="form-group">
                                    <input v-model.trim="nameOrId"  type="text"
                                           class="form-control" placeholder="请输入股票名或股票代码">
                                </div>
                                <div class="form-group">
                                    <input v-model.trim="keywords"
                                           type="text" class="form-control" placeholder="请输入搜索的关键词">
                                </div>
                                <button @click="handleSearch" type="submit" class="btn btn-lg btn-success btn-block">
                                    <i class="fa fa-search"></i> 搜索
                                </button>
                            </div>
                        </div>
                        <div class="clearfix"></div>
                    </div>
                </div>

<!--                <Search :list="searchList" :nameOrId="nameOrId" :keywords="keywords"/>-->
                <div class="panel panel-default list-panel search-results">
                    <div class="panel-heading">
                        <h3 class="panel-title">
                            <i class="fa fa-search"></i>
                            搜索共 {{ searchList.length }} 条

                            <div v-if="searchList.length" class="pull-right" >
                                <button class="btn btn-default btn-sm" href="javascript:;" @click="save()">
                                    保存搜索信息
                                </button>
                                <button class="btn btn-default btn-sm" href="javascript:;" @click="sendEmail()">
                                    打包发送
                                </button>
                            </div>
                        </h3>
                    </div>
                    <div class="panel-body">
                        <div v-for="result in searchList" class="result">
                            <h2 class="title">
                                <a target="_blank" :href="result.link">{{result.code}} <span
                                        v-html="result.title"></span></a>
                            </h2>
                            <div class="desc" v-html="result.content"></div>
                            <hr>
                        </div>
                        <div v-if="!searchList.length" class="empty-block">
                            没有任何数据~~
                        </div>
                    </div>
                </div>

                <!-- 分页组件 -->
                <div class="panel-footer text-right remove-padding-horizontal pager-footer">
                    <Pagination
                            :currentPage="currentPage"
                            :total="total"
                            :pageSize="pageSize"
                            :onPageChange="changePage"
                    />
                </div>
            </div>
        </div>
        <!-- 侧栏 -->
<!--        <TheSidebar/>-->
    </div>
</template>

<script>
    import {mapState} from "vuex";
    // 引入 TheSidebar.vue 的默认值
    import TheSidebar from "@/components/layouts/TheSidebar";
    import axios from 'axios';

    export default {
        name: "Home",
        components: {
            // 局部注册 TheSidebar
            TheSidebar,
        },
        data() {
            return {
                nameOrId: "",
                keywords: "",
                value: "",
                searchList: [],
                msg: "",
                msgType: "",
                msgShow: false,
                articles: [],
                filter: "default",
                filters: [
                    {filter: "default", name: "活跃", title: "最后回复排序"},
                    {filter: "excellent", name: "精华", title: "只看加精的话题"},
                    {filter: "vote", name: "投票", title: "点赞数排序"},
                    {filter: "recent", name: "最近", title: "发布时间排序"},
                    {filter: "noreply", name: "零回复", title: "无人问津的话题"}
                ],
                total: 0, // 总数
                pageSize: 20 // 每页条数
            };
        },
        beforeRouteEnter(to, from, next) {
            const fromName = from.name;
            const logout = to.params.logout;

            next(vm => {
                if (vm.$store.state.auth) {
                    switch (fromName) {
                        case "Register":
                            vm.showMsg("注册成功");
                            break;
                        case "Login":
                            vm.showMsg("登录成功");
                            break;
                    }
                } else if (logout) {
                    vm.showMsg("操作成功");
                }

                vm.setDataByFilter(to.query.filter);
            });
        },
        computed: {
            ...mapState(["auth", "user"]),
            // 当前页，从查询参数 page 返回
            currentPage() {
                return parseInt(this.$route.query.page) || 1;
            }
        },
        watch: {
            auth(value) {
                if (!value) {
                    this.showMsg("操作成功");
                }
            },
            $route(to) {
                this.setDataByFilter(to.query.filter);
            }
        },
        methods: {
            handleSearch() {
                const search = {
                    nameOrId: this.nameOrId,
                    keywords: this.keywords,
                }
                axios.post('http://127.0.0.1:8000/api/search/', search).then((res) => {
                    const code = parseInt(res.data['code'])
                    const msg = res.data['msg']
                    if(code === 2000){
                        this.searchList = res.data["data"] || []
                        this.showMsgSuccess(msg)
                    }else if(code === 2001){
                        this.showMsgWarning(msg)

                    }
                });
            },

            save() {
                if(this.user){
                    const search = {
                    nameOrId: this.nameOrId,
                    keywords: this.keywords,
                    action: "save"
                }
                axios.post('http://127.0.0.1:8000/api/dingzhe/', search).then((res) => {
                    console.log(res.data)
                    const code = parseInt(res.data['code'])
                    const msg = res.data['msg']
                    console.log("this.showMsgSuccess(msg)")
                    this.showMsgSuccess(msg)
                    if (code === 3000) {
                        console.log(code)
                        this.showMsgSuccess(msg)
                    } else if (code === 3001) {
                        this.showMsgWarning(msg)
                        console.log(code)
                    }
                });
                }else{
                      this.$swal({
                        text: '该功能需要登录',
                        confirmButtonText: '登陆'
                      }).then((res) => {
                          this.$router.push({
                              name: 'Login'
                          })
                      })
                }

            },
            sendEmail(){
                  const search = {
                    nameOrId: this.nameOrId,
                    keywords: this.keywords,
                    action: "sendEmail",
                    email: this.user.email
                }
                axios.post('http://127.0.0.1:8000/api/dingzhe/', search).then((res) => {
                    console.log(res.data)
                    const code = parseInt(res.data['code'])
                    const msg = res.data['msg']
                    this.showMsgSuccess(msg)
                    if (code === 3002) {
                        console.log(code)
                        this.showMsgSuccess(msg)
                    }
                });
            },
            showMsgSuccess(msg, type = "success") {
                this.msg = msg;
                this.msgType = type;
                this.msgShow = true;
            },
            showMsgWarning(msg, type = "warning") {
                this.msg = msg;
                this.msgType = type;
                this.msgShow = true;
            },
            setDataByFilter(filter = "default") {
                // 每页条数
                const pageSize = this.pageSize;
                // 当前页
                const currentPage = this.currentPage;
                // 过滤后的所有文章
                const allArticles = this.$store.getters.getArticlesByFilter(filter);

                this.filter = filter;
                // 文章总数
                this.total = allArticles.length;
                // 当前页的文章
                this.articles = allArticles.slice(
                    pageSize * (currentPage - 1),
                    pageSize * currentPage
                );
            },
            // 回调，组件的当前页改变时调用
            changePage(page) {
                // 在查询参数中混入 page，并跳转到该地址
                // 混入部分等价于 Object.assign({}, this.$route.query, { page: page })
                this.$router.push({query: {...this.$route.query, page}});
            }
        }
    };
</script>

<style scoped>
    .result a:hover, .result a:focus {
        color: #d6514d;
        transition: color .15s ease;
    }

    .panel-title .btn {
        margin-left: 5px;
    }

    .desc {
        overflow: hidden;
        text-overflow: ellipsis;
        display: -webkit-box;
        -webkit-box-orient: vertical;
        -webkit-line-clamp: 3;
    }
    @media (max-width: 767px) {
        .pull-right{
            margin-top:-10px
        }
    }
</style>