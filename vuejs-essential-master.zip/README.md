# vuejs-essential

> [Vue.js 实战 - 基础篇](https://vuejscaff.com/courses/vuejs-essential) 源码，使用 Vue.js 开发一个类似 [VuejsCaff 社区](https://vuejscaff.com/topics) 部分的网站

## Build Setup

``` bash
# install dependencies
npm install

# serve with hot reload at localhost:8080
npm run serve

# build for production with minification
npm run build
```

## Preview

https://ryunpu.github.io/vuejs-essential/dist/

![网站首页](https://user-images.githubusercontent.com/6168498/40305711-3ec06df0-5d2e-11e8-8cc0-58869c11afdb.png)
